export const config = {
  api: {
    responseLimit: false,
    bodyParser: false,
  },
};

export default function handler(req, res) {
  const { jobId } = req.query;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const send = (event, data) => {
    try {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      if (res.flush) res.flush();
    } catch {}
  };

  let lastIndex = 0;

  const tick = () => {
    const job = global._crawlJobs?.[jobId];
    if (!job) {
      send('error', { msg: 'Job não encontrado' });
      return cleanup();
    }

    // Flush new log entries
    const logs = job.logs || [];
    while (lastIndex < logs.length) {
      const entry = logs[lastIndex++];
      send('log', entry);

      // Emit progress events
      if (entry.phase === 'crawl') {
        send('progress', { phase: 'crawl', done: entry.done, total: entry.total });
      } else if (entry.phase === 'assets') {
        send('progress', { phase: 'assets', done: entry.done, total: entry.total });
      } else if (entry.phase === 'done') {
        send('done', { stats: entry.stats });
        return cleanup();
      }
    }

    if (job.status === 'error') {
      send('error', { msg: job.error || 'Erro desconhecido' });
      return cleanup();
    }

    if (job.status === 'done') {
      send('done', { stats: job.stats });
      return cleanup();
    }
  };

  const interval = setInterval(tick, 300);
  // Send a keepalive comment every 15s
  const keepalive = setInterval(() => {
    try { res.write(': keepalive\n\n'); if (res.flush) res.flush(); } catch {}
  }, 15000);

  function cleanup() {
    clearInterval(interval);
    clearInterval(keepalive);
    try { res.end(); } catch {}
  }

  req.on('close', cleanup);

  // Safety timeout: 10 minutes
  setTimeout(cleanup, 10 * 60 * 1000);
}
