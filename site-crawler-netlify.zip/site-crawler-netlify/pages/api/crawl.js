const { normalizeUrl, isSameOrigin, urlToPagePath, urlToAssetPath, fetchUrl, rewriteHtml, extractLinks } = require('../../lib/crawler');
const archiver = require('archiver');
const { URL } = require('url');
const { PassThrough } = require('stream');

// In-memory job store (works for serverless with caveats — job lives in same function instance)
// For Netlify Functions, we stream everything in one long-running SSE response instead.

export const config = {
  api: {
    responseLimit: false,
    bodyParser: true,
  },
};

// Global job store per process instance
if (!global._crawlJobs) global._crawlJobs = {};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { url, maxPages = 60, maxDepth = 4 } = req.body;
  if (!url) return res.status(400).json({ error: 'URL obrigatória' });

  // Generate job id
  const jobId = Math.random().toString(36).slice(2, 10);

  // Store job placeholder
  global._crawlJobs[jobId] = { status: 'pending', logs: [], zipBuffer: null };

  // Start async crawl (fire and forget)
  runCrawl(jobId, url, { maxPages, maxDepth }).catch(err => {
    if (global._crawlJobs[jobId]) {
      global._crawlJobs[jobId].status = 'error';
      global._crawlJobs[jobId].error = err.message;
    }
  });

  return res.status(200).json({ jobId });
}

async function runCrawl(jobId, startUrl, options) {
  const job = global._crawlJobs[jobId];
  const { maxPages, maxDepth } = options;
  const base = new URL(startUrl);
  const origin = base.origin;

  job.status = 'running';
  job.startedAt = Date.now();

  const push = (type, msg, extra = {}) => {
    const entry = { type, msg, ts: Date.now(), ...extra };
    job.logs.push(entry);
  };

  push('info', `🚀 Iniciando: ${startUrl}`);
  push('info', `📋 Máx: ${maxPages} páginas, profundidade ${maxDepth}`);

  const visited   = new Set();
  const pageData  = new Map(); // url -> html string
  const pageMap   = new Map(); // url -> localPath
  const assetMap  = new Map(); // url -> localPath
  const assetData = new Map(); // url -> Buffer
  const urlMap    = new Map(); // url -> localPath (pages + assets)

  const queue = [{ url: normalizeUrl(startUrl, startUrl), depth: 0 }];
  let pageCount = 0;

  // ── Phase 1: crawl pages ──────────────────────────────────────
  while (queue.length > 0 && pageCount < maxPages) {
    const { url, depth } = queue.shift();
    if (!url || visited.has(url) || !isSameOrigin(url, origin)) continue;
    if (depth > maxDepth) continue;
    visited.add(url);

    const result = await fetchUrl(url);
    if (!result) continue;
    if (!/text\/html/i.test(result.contentType)) continue;

    pageCount++;
    const localPath = urlToPagePath(url);
    pageMap.set(url, localPath);
    urlMap.set(url, localPath);
    if (result.finalUrl && result.finalUrl !== url) urlMap.set(result.finalUrl, localPath);

    const html = result.data.toString('utf-8');
    pageData.set(url, html);

    push('ok', `✓ [${pageCount}] ${url}`, { phase: 'crawl', done: pageCount, total: maxPages });
    job.pageCount = pageCount;

    const { links, assets } = extractLinks(html, url, origin);

    links.forEach(l => {
      if (!visited.has(l)) queue.push({ url: l, depth: depth + 1 });
    });

    assets.forEach(a => {
      if (!assetMap.has(a)) {
        const lp = urlToAssetPath(a);
        assetMap.set(a, lp);
        urlMap.set(a, lp);
      }
    });
  }

  push('info', `📦 ${pageCount} páginas. Baixando ${assetMap.size} assets…`);
  job.assetTotal = assetMap.size;

  // ── Phase 2: download assets in batches ──────────────────────
  const assetEntries = [...assetMap.entries()];
  let assetDone = 0;

  for (let i = 0; i < assetEntries.length; i += 8) {
    const batch = assetEntries.slice(i, i + 8);
    await Promise.all(batch.map(async ([assetUrl, localPath]) => {
      const r = await fetchUrl(assetUrl);
      assetDone++;
      if (!r) return;
      assetData.set(assetUrl, r.data);

      // Scan CSS for nested urls
      if (/text\/css/i.test(r.contentType) || localPath.endsWith('.css')) {
        const css = r.data.toString('utf-8');
        const found = [...css.matchAll(/url\(['"]?([^'")\s]+)['"]?\)/g)].map(m => m[1]);
        for (const u of found) {
          if (u.startsWith('data:')) continue;
          const { normalizeUrl: nu } = require('../../lib/crawler');
          const abs = nu(u, assetUrl);
          if (!abs || assetMap.has(abs)) continue;
          const lp2 = urlToAssetPath(abs);
          assetMap.set(abs, lp2);
          urlMap.set(abs, lp2);
          assetEntries.push([abs, lp2]);
          const r2 = await fetchUrl(abs);
          if (r2) assetData.set(abs, r2.data);
        }
      }

      push('ok', `↓ ${localPath}`, { phase: 'assets', done: assetDone, total: assetEntries.length });
      job.assetDone = assetDone;
    }));
  }

  push('info', `✍ Reescrevendo links…`);

  // ── Phase 3: build ZIP in memory ─────────────────────────────
  const zipBuffer = await new Promise((resolve, reject) => {
    const buffers = [];
    const pass = new PassThrough();
    pass.on('data', d => buffers.push(d));
    pass.on('end', () => resolve(Buffer.concat(buffers)));
    pass.on('error', reject);

    const archive = archiver('zip', { zlib: { level: 6 } });
    archive.on('error', reject);
    archive.pipe(pass);

    // Add rewritten pages
    for (const [pageUrl, localPath] of pageMap.entries()) {
      const rawHtml = pageData.get(pageUrl);
      if (!rawHtml) continue;
      const rewritten = rewriteHtml(rawHtml, pageUrl, urlMap);
      archive.append(Buffer.from(rewritten, 'utf-8'), { name: localPath });
    }

    // Add assets
    for (const [assetUrl, localPath] of assetMap.entries()) {
      const buf = assetData.get(assetUrl);
      if (buf) archive.append(buf, { name: localPath });
    }

    archive.finalize();
  });

  job.status = 'done';
  job.zipBuffer = zipBuffer;
  job.stats = { pages: pageCount, assets: assetDone, size: zipBuffer.length };

  push('ok', `✅ Pronto! ${pageCount} páginas · ${assetDone} assets · ${(zipBuffer.length / 1024 / 1024).toFixed(2)} MB`, {
    phase: 'done', stats: job.stats
  });
}
