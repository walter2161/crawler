export const config = {
  api: {
    responseLimit: false,
    bodyParser: false,
  },
};

export default function handler(req, res) {
  const { jobId } = req.query;
  const job = global._crawlJobs?.[jobId];

  if (!job || job.status !== 'done' || !job.zipBuffer) {
    return res.status(404).json({ error: 'ZIP não disponível. O job ainda não terminou ou não existe.' });
  }

  const domain = (req.query.domain || 'site').replace(/[^a-z0-9_\-]/gi, '_');
  const filename = `${domain}_crawl.zip`;

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Length', job.zipBuffer.length);

  res.send(job.zipBuffer);

  // Free memory after a minute
  setTimeout(() => {
    if (global._crawlJobs?.[jobId]) {
      delete global._crawlJobs[jobId];
    }
  }, 60 * 1000);
}
