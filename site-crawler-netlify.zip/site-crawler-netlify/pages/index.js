import { useState, useRef, useEffect } from 'react';
import Head from 'next/head';

export default function Home() {
  const [url, setUrl]           = useState('');
  const [maxPages, setMaxPages] = useState(50);
  const [maxDepth, setMaxDepth] = useState(4);
  const [phase, setPhase]       = useState('idle'); // idle | running | done | error
  const [logs, setLogs]         = useState([]);
  const [progress, setProgress] = useState({ pages: { done: 0, total: 0 }, assets: { done: 0, total: 0 } });
  const [stats, setStats]       = useState(null);
  const [jobId, setJobId]       = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const termRef = useRef(null);
  const esRef   = useRef(null);

  useEffect(() => {
    if (termRef.current) {
      termRef.current.scrollTop = termRef.current.scrollHeight;
    }
  }, [logs]);

  const addLog = (entry) => setLogs(prev => [...prev, entry]);

  const startCrawl = async () => {
    if (!url.trim()) return;
    if (!/^https?:\/\//i.test(url)) {
      setErrorMsg('A URL deve começar com http:// ou https://');
      return;
    }

    // Reset
    setLogs([]);
    setProgress({ pages: { done: 0, total: 0 }, assets: { done: 0, total: 0 } });
    setStats(null);
    setErrorMsg('');
    setPhase('running');

    let id;
    try {
      const res = await fetch('/api/crawl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim(), maxPages, maxDepth }),
      });
      if (!res.ok) throw new Error(`Erro ${res.status}`);
      const data = await res.json();
      id = data.jobId;
      setJobId(id);
    } catch (e) {
      setErrorMsg(`Falha ao iniciar: ${e.message}`);
      setPhase('error');
      return;
    }

    // SSE
    const es = new EventSource(`/api/status/${id}`);
    esRef.current = es;

    es.addEventListener('log', e => {
      const entry = JSON.parse(e.data);
      addLog(entry);
    });

    es.addEventListener('progress', e => {
      const { phase: ph, done, total } = JSON.parse(e.data);
      setProgress(prev => ({
        ...prev,
        [ph === 'crawl' ? 'pages' : 'assets']: { done, total },
      }));
    });

    es.addEventListener('done', e => {
      const { stats } = JSON.parse(e.data);
      setStats(stats);
      setPhase('done');
      es.close();
    });

    es.addEventListener('error', e => {
      try {
        const { msg } = JSON.parse(e.data);
        setErrorMsg(msg);
      } catch {}
      setPhase('error');
      es.close();
    });
  };

  const fmt = (bytes) => {
    if (!bytes) return '—';
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB';
    return (bytes / 1024).toFixed(0) + ' KB';
  };

  const pct = (done, total) => total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;

  const domain = (() => { try { return new URL(url).hostname.replace('www.', ''); } catch { return 'site'; } })();

  return (
    <>
      <Head>
        <title>Site Crawler</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Bricolage+Grotesque:opsz,wght@12..96,300;12..96,500;12..96,700;12..96,800&display=swap" rel="stylesheet" />
      </Head>

      <style jsx global>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
          --bg: #f5f0e8;
          --card: #faf7f2;
          --border: #d8d0c4;
          --border2: #c8bfb2;
          --ink: #1a1714;
          --muted: #8a8070;
          --accent: #c84b2f;
          --accent2: #2563c8;
          --accent3: #1a7a4a;
          --warn: #b07820;
        }
        body {
          background: var(--bg);
          background-image: radial-gradient(circle, var(--border) 1px, transparent 1px);
          background-size: 24px 24px;
          color: var(--ink);
          font-family: 'Bricolage Grotesque', sans-serif;
          min-height: 100vh;
        }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 3px; }
      `}</style>

      <div style={{ maxWidth: 820, margin: '0 auto', padding: '64px 24px 100px' }}>

        {/* Header */}
        <div style={{ display: 'flex', gap: 20, marginBottom: 52, alignItems: 'flex-start' }}>
          <div style={{
            width: 56, height: 56, background: 'var(--ink)', borderRadius: 12,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 26, flexShrink: 0, marginTop: 4,
            boxShadow: '3px 3px 0 var(--accent)'
          }}>🕷</div>
          <div>
            <h1 style={{ fontSize: 'clamp(1.8rem,4vw,2.8rem)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.1 }}>
              Site <span style={{ color: 'var(--accent)' }}>Crawler</span>
            </h1>
            <p style={{ marginTop: 10, color: 'var(--muted)', fontSize: '0.95rem', fontWeight: 300, lineHeight: 1.6, maxWidth: 460 }}>
              Cole a URL de qualquer site. O crawler escaneia todas as páginas, baixa os assets e gera um ZIP completo e funcional.
            </p>
          </div>
        </div>

        {/* Input card */}
        <div style={{ background: 'var(--card)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 28, boxShadow: '4px 4px 0 var(--border)', marginBottom: 20 }}>
          <div style={{ fontFamily: 'DM Mono, monospace', fontSize: '0.7rem', color: 'var(--muted)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 14 }}>
            // url do site
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <input
              type="url"
              value={url}
              onChange={e => setUrl(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && phase !== 'running' && startCrawl()}
              placeholder="https://exemplo.com.br"
              disabled={phase === 'running'}
              style={{
                flex: 1, padding: '14px 16px',
                background: 'var(--bg)', border: '1.5px solid var(--border2)',
                borderRadius: 10, fontFamily: 'DM Mono, monospace', fontSize: '0.88rem',
                color: 'var(--ink)', outline: 'none',
                opacity: phase === 'running' ? 0.6 : 1,
              }}
            />
            <button
              onClick={startCrawl}
              disabled={phase === 'running' || !url}
              style={{
                padding: '14px 22px', background: phase === 'running' ? '#999' : 'var(--ink)',
                border: '1.5px solid var(--ink)', borderRadius: 10,
                color: 'white', fontFamily: 'Bricolage Grotesque, sans-serif',
                fontSize: '0.9rem', fontWeight: 700, cursor: phase === 'running' ? 'not-allowed' : 'pointer',
                whiteSpace: 'nowrap', boxShadow: '3px 3px 0 rgba(26,23,20,0.2)',
                display: 'flex', alignItems: 'center', gap: 8,
                transition: 'all 0.15s',
              }}
            >
              {phase === 'running' ? '⏳ Crawling…' : '🔍 Iniciar crawl'}
            </button>
          </div>

          {/* Sliders */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 20 }}>
            {[
              { label: 'Máx. páginas', value: maxPages, set: setMaxPages, min: 5, max: 300, step: 5 },
              { label: 'Profundidade máx.', value: maxDepth, set: setMaxDepth, min: 1, max: 10, step: 1 },
            ].map(({ label, value, set, min, max, step }) => (
              <div key={label} style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 10, padding: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontFamily: 'DM Mono, monospace', fontSize: '0.7rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{label}</span>
                  <span style={{ fontFamily: 'DM Mono, monospace', fontSize: '0.95rem', fontWeight: 500 }}>{value}</span>
                </div>
                <input type="range" min={min} max={max} step={step} value={value}
                  onChange={e => set(+e.target.value)}
                  disabled={phase === 'running'}
                  style={{ width: '100%', accentColor: 'var(--accent)' }} />
              </div>
            ))}
          </div>

          <div style={{ marginTop: 16, background: '#fef9ec', border: '1.5px solid #e8d090', borderRadius: 10, padding: '12px 16px', fontSize: '0.82rem', color: 'var(--warn)', fontFamily: 'DM Mono, monospace', lineHeight: 1.5 }}>
            ⚠ Sites com login, proteção anti-bot ou SPAs (React/Vue/Angular) podem ter resultado parcial.
          </div>
        </div>

        {/* Progress */}
        {(phase === 'running' || phase === 'done' || phase === 'error') && (
          <div style={{ background: 'var(--card)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 28, boxShadow: '4px 4px 0 var(--border)', marginBottom: 20 }}>
            <div style={{ fontFamily: 'DM Mono, monospace', fontSize: '0.7rem', color: 'var(--muted)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 16 }}>
              // progresso
            </div>

            {/* Phase bars */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
              {[
                { label: 'Páginas', key: 'pages', color: 'var(--accent)' },
                { label: 'Assets', key: 'assets', color: 'var(--accent2)' },
              ].map(({ label, key, color }) => (
                <div key={key} style={{ background: 'var(--bg)', border: '1.5px solid var(--border)', borderRadius: 10, padding: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'DM Mono, monospace', fontSize: '0.7rem', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: 8 }}>
                    <span>{label}</span>
                    <span>{progress[key].done} / {progress[key].total || '?'}</span>
                  </div>
                  <div style={{ height: 6, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{ height: '100%', background: color, borderRadius: 3, width: pct(progress[key].done, progress[key].total) + '%', transition: 'width 0.4s ease' }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Status */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              {phase === 'running' && (
                <div style={{
                  width: 16, height: 16, borderRadius: '50%',
                  border: '2px solid var(--border)', borderTopColor: 'var(--accent)',
                  animation: 'spin 0.7s linear infinite', flexShrink: 0,
                }} />
              )}
              <span style={{ fontFamily: 'DM Mono, monospace', fontSize: '0.8rem', color: 'var(--muted)' }}>
                {phase === 'running' ? (logs[logs.length - 1]?.msg?.slice(0, 90) || 'Processando…') : phase === 'done' ? '✅ Concluído!' : '❌ Erro'}
              </span>
            </div>

            {/* Terminal */}
            <div style={{ background: '#1a1714', borderRadius: 10, overflow: 'hidden', border: '1.5px solid #333' }}>
              <div style={{ background: '#2a2420', padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 6 }}>
                {['#ff5f57','#ffbd2e','#28c840'].map(c => (
                  <div key={c} style={{ width: 10, height: 10, borderRadius: '50%', background: c }} />
                ))}
                <span style={{ fontFamily: 'DM Mono, monospace', fontSize: '0.7rem', color: '#666', marginLeft: 6 }}>crawler · log</span>
              </div>
              <div ref={termRef} style={{ padding: '14px 16px', fontFamily: 'DM Mono, monospace', fontSize: '0.75rem', lineHeight: 1.7, color: '#b0a898', maxHeight: 240, overflowY: 'auto' }}>
                {logs.map((entry, i) => (
                  <div key={i} style={{ color: entry.type === 'ok' ? '#4ec97a' : entry.type === 'warn' ? '#f5a623' : entry.type === 'info' ? '#7eb8f5' : '#b0a898' }}>
                    {entry.msg}
                  </div>
                ))}
                {phase === 'running' && <div style={{ color: '#555' }}>▋</div>}
              </div>
            </div>

            {errorMsg && (
              <div style={{ marginTop: 16, background: '#fff0f0', border: '1.5px solid #f5a0a0', borderRadius: 10, padding: 16, fontFamily: 'DM Mono, monospace', fontSize: '0.82rem', color: '#c84040' }}>
                ❌ {errorMsg}
              </div>
            )}
          </div>
        )}

        {/* Result */}
        {phase === 'done' && stats && (
          <div style={{ background: '#f0faf4', border: '1.5px solid #8ad4aa', borderRadius: 16, padding: 28, boxShadow: '4px 4px 0 rgba(74,180,120,0.2)' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8, color: 'var(--accent3)' }}>
              ✅ Site capturado com sucesso!
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 22 }}>
              {[
                { val: stats.pages, lbl: 'páginas HTML' },
                { val: stats.assets, lbl: 'assets baixados' },
                { val: fmt(stats.size), lbl: 'tamanho ZIP' },
              ].map(({ val, lbl }) => (
                <div key={lbl} style={{ background: 'white', border: '1.5px solid #c0e8d0', borderRadius: 10, padding: 14, textAlign: 'center' }}>
                  <span style={{ fontFamily: 'DM Mono, monospace', fontSize: '1.5rem', fontWeight: 500, color: 'var(--accent3)', display: 'block' }}>{val}</span>
                  <span style={{ fontSize: '0.72rem', color: 'var(--muted)', marginTop: 2, display: 'block' }}>{lbl}</span>
                </div>
              ))}
            </div>

            <a
              href={`/api/download/${jobId}?domain=${encodeURIComponent(domain)}`}
              download
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                width: '100%', padding: 16, background: 'var(--accent3)',
                border: '1.5px solid #145c35', borderRadius: 10, color: 'white',
                fontFamily: 'Bricolage Grotesque, sans-serif', fontSize: '1rem', fontWeight: 700,
                cursor: 'pointer', textDecoration: 'none', boxShadow: '3px 3px 0 #145c35',
                transition: 'all 0.15s',
              }}
            >
              ⬇ Baixar {domain}_crawl.zip
            </a>

            <p style={{ marginTop: 14, fontFamily: 'DM Mono, monospace', fontSize: '0.7rem', color: 'var(--muted)', lineHeight: 1.6, textAlign: 'center' }}>
              Descompacte o ZIP e abra o index.html — todos os links e assets foram reescritos para caminhos relativos.
            </p>
          </div>
        )}

      </div>

      <style jsx global>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </>
  );
}
