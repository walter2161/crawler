# 🕷 Site Crawler

Ferramenta web que escaneia um site inteiro e gera um ZIP completo com todas as páginas e assets (imagens, CSS, JS, fontes), com todos os links reescritos para caminhos relativos locais.

## Deploy no Netlify (1 clique)

1. Faça fork deste repositório no GitHub
2. Acesse [app.netlify.com](https://app.netlify.com) → **Add new site** → **Import an existing project**
3. Conecte seu GitHub e selecione este repositório
4. As configurações são detectadas automaticamente pelo `netlify.toml`:
   - **Build command:** `npm run build`
   - **Publish directory:** `.next`
5. Clique em **Deploy site** — pronto!

## Como usar

1. Acesse a URL do seu site no Netlify
2. Cole a URL do site que deseja capturar
3. Ajuste o limite de páginas e profundidade
4. Clique em **Iniciar crawl**
5. Acompanhe o progresso em tempo real
6. Baixe o ZIP gerado

## Tecnologias

- **Next.js 14** — framework React com API Routes
- **Netlify Functions** — backend serverless via `@netlify/plugin-nextjs`
- **cheerio** — parse e reescrita de HTML
- **axios** — download de páginas e assets
- **archiver** — geração do ZIP em memória

## Limitações

- Sites com login/autenticação terão acesso parcial
- SPAs (React, Vue, Angular) que dependem de JS para renderizar podem não capturar todo o conteúdo
- Sites com proteção anti-bot (Cloudflare, etc.) podem bloquear o crawler
- Netlify Functions têm timeout de 26s na versão gratuita — sites grandes podem ser interrompidos
  - Para sites grandes, use a versão local com `node server.js`
